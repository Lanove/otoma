<div class="container-fluid">
    <div class="noDeviceError">
        <div class="row">
            <div class="col-12">
                <h3 class="error-unsmile">:(</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="error-template">
                    <h1>
                        Oops!</h1>
                    <h2>
                        Tidak ada perangkat</h2>
                    <div class="error-details">
                        Tambahkan perangkat dan operasikan sekarang juga!
                    </div>
                    <div class="error-actions">
                        <a href="#">
                            <button class="btn btn-info mt-2" id="goHelp"><i class="fa fa-question-circle"></i> Panduan</button></a>
                        <a href="#">
                            <button class="btn btn-info mt-2" id="contactUs"><i class="fas fa-paper-plane"></i> Kontak Kami</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>